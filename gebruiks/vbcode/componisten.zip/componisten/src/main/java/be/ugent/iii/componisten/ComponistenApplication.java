package be.ugent.iii.componisten;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComponistenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComponistenApplication.class, args);
	}

}
