package be.ugent.iii.componisten;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponistenApplicationTests {

	@Test
	void contextLoads() {
	}

}
