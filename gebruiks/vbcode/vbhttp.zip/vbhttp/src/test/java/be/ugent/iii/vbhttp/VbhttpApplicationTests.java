package be.ugent.iii.vbhttp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VbhttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
