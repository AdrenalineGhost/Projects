package be.ugent.iii.vbhttp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VbhttpApplication {

	public static void main(String[] args) {
		SpringApplication.run(VbhttpApplication.class, args);
	}

}
