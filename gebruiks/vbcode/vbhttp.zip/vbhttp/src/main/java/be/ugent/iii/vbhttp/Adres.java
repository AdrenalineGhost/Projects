package be.ugent.iii.vbhttp;

public class Adres {
    private String naam;
    private String adreslijn;

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getAdreslijn() {
        return adreslijn;
    }

    public void setAdreslijn(String adreslijn) {
        this.adreslijn = adreslijn;
    }
}
