import gokjeNieuw from "./gokje.js";
gokjeNieuw();


