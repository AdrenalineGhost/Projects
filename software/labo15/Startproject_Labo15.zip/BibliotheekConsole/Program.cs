﻿// See https://aka.ms/new-console-template for more information

using BibliotheekConsole;
using Catalogus;

//Dummy();
YamlBibliotheek();
void YamlBibliotheek()
{
    YamlBibliotheek bib = new();
    IBibItem start = bib.Bibliotheek;
    Console.WriteLine(start.Toon(0));
 
}
void Dummy()
{
    DummyBibliotheek bib = new();
    IBibItem start = bib.Bibliotheek;
    Console.WriteLine(start.Toon(0));

    IBibItem item = start.Zoek("ID07");
    Console.WriteLine(item.Toon(0) + "\n");

    Console.WriteLine("ZoekTrefwoord:");
    ISet<IBibItem> gevonden = start.ZoekTrefwoord("en");
    foreach (IBibItem ib in gevonden)
    {
        Console.WriteLine(ib.Toon(0));
    }
}