﻿using System;

namespace Samenwerking
{
    [Serializable]
    internal class NotConnected : Exception
    {
        public NotConnected()
        {
        }
       
    }
}