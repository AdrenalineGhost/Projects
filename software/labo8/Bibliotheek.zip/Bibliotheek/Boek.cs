﻿namespace Bibliotheek
{
    public class Boek
    {
        public string Titel { get; set; }
        public string Auteur { get; set; }
        public string Uitgeverij { get; set; }
        public int Jaartal { get; set; }
        public string Id { get; set; }
    }
}
