﻿// See https://aka.ms/new-console-template for more information
using Bibliotheek;

Library library = new();

Console.Out.WriteLine("Aantal items: " + library.Items.Count);
