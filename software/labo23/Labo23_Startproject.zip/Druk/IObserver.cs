﻿namespace Druk
{
    public interface IObserver
    {
        void Update();
    }
}
