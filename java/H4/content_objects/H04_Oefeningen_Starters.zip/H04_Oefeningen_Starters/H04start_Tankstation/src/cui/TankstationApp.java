package cui;

public class TankstationApp {

	public static void main(String[] args) {
		new TankstationApp().startTanken();
	}

	private void startTanken() {
		// TODO
	}

	private int geefAantalLiter() {
		// TODO
	}

	private int geefPompNummer() {
		// TODO
	}
}
