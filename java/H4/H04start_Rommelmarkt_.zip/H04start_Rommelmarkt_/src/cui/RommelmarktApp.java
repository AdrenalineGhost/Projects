package cui;

import java.util.Scanner;

public class RommelmarktApp {

	public static void main(String[] args) {
		new RommelmarktApp().simuleerRommelmarkt();
	}

	private Scanner invoer = new Scanner(System.in);
	
	private void simuleerRommelmarkt() {
		//TODO
	}

	private double geefBedrag() {
		//TODO
	}

	private int geefKeuze(int aantalKramen, String menu) {
		//TODO
	}

	private int geefAantalKramen() {
		//TODO
	}

	private String geefKraamhouder(int kraamnummer) {
		//TODO
	}

	private int geefBreedteKraam(int kraamnummer) {
		//TODO
	}
}
