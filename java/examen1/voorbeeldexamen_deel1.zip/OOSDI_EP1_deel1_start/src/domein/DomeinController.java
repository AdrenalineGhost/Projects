package domein;



public class DomeinController 
{
	private Tuincentrum tuincentrum;

	public DomeinController() {
		//TODO
	}

	public void voegPlantToe(String naam, char soortCode, int hoogteInCm, double prijsInEuro, int aantalInVoorraad) {
		//TODO
		
	}

	public PlantDTO[] geefAllePlanten(boolean inVoorraad) {
		//TODO
	}

	
	public double bepaalWaardeVerkoop()
	{
		//TODO
	}

	public int[] maakOverzichtPlantenPerHoogte() 
	{
		//TODO
	}

}
