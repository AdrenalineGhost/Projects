package boggledeel1;

/**
 *
 * @author ...
 */
public class Main {

    public static void main(String[] args) {
        // to do
    }
    
}
