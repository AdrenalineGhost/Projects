package boggledeel1;

import java.util.Random;

/**
 *
 * @author ...
 */
public class Dobbelsteen {
        
    private char[] letters;
    private char waarde;
    
    
}
