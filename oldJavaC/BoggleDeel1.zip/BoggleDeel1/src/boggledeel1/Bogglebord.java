package boggledeel1;

/**
 *
 * @author ...
 */
public class Bogglebord {

    public static final int DIM = 4;
    
    private Dobbelsteen[][] bord;

}
